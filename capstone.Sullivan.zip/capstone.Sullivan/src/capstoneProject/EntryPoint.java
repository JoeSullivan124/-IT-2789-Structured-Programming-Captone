package capstoneProject;

public class EntryPoint {

	public static void main(String[] args)
	{
		new capstoneProject();

	}
}
