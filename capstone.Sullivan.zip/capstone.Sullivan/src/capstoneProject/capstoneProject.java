package capstoneProject;

import javax.swing.JOptionPane;

public class capstoneProject {
	// Joe Sullivan Capstone project

	public capstoneProject()

	{
		String minus = "";
		String temp = "";
		String result = "";
		String Point = "";
		String input = "";
//i reinstalled eclipse after you said something could be corrupted in class and +- no longer cause errors
		while (true) {
			input = JOptionPane.showInputDialog("enter a number");
			double test = Double.parseDouble(input);
			if (test * 0 == 0) {
				// System.out.println("valid number");
				break;
			} else {
				//System.out.println("invald number");
				//program will barf
			}
		}
		CharSequence searchString1 = ".";
		if (input.length() > 1 && input.contains(searchString1)) {
			input = input.substring(0, input.length() - 2);
			// System.out.println("there is a decimal");
			Point = " point ";

		} else {
			// System.out.println("there is not a decimal");
			Point = "";
		}

		CharSequence searchString2 = "+";
		if (input.length() > 1 && input.contains(searchString2)) {
			input = deleteCharAt(input, 0);
			// System.out.println("there is a positive symbol");
		} else {
			// System.out.println("there is not a positive symbol");
		}
		CharSequence searchString3 = "-";
		if (input.length() > 1 && input.contains(searchString3)) {
			input = deleteCharAt(input, 0);
			minus = "minus ";
			// System.out.println("there is a negitive symbol");
		} else {
			// System.out.println("there is not a negitive symbol");
		}
		{

		}

		if (input.length() > 3) {

			for (int a = 0; a < input.length() - 3; a++) {

				temp += input.charAt(a);

			}
			result += findingThreeNumbers(temp) + " thousand ";

		}
		result += findingThreeNumbers(input);
		JOptionPane.showMessageDialog(null, "your number " + input +

				" in word is " + minus + result + Point);

	}

	public String deleteCharAt(String input, int index) // used to remove decimal and positive/negitve sign
	{
		return input.substring(0, index) + input.substring(index + 1);
	}

	public String findingThreeNumbers(String number)// put numbers into 3s
	{

		String result;
		result = findHundreds(number);
		result += FindingTens(number);
		if (number.length() > 1 && findCharacter(number, 2) != '1')

			result += FindingOnes(number);

		return result;

	}

	public String FindingOnes(String theNumber) {

		char character = findCharacter(theNumber, 1);
		return decodeNumber(character);

	}

	public String FindingTens(String theNumber) {

		if (theNumber.length() > 1) {

			char character = findCharacter(theNumber, 2);
			if (character == '1') {

				return teens(theNumber);

			} else {

				return tensPlace(theNumber,

						character) + " ";

			}

		}
		return "";

	}

	public String findHundreds(String number) {

		if (number.length() > 2) {

			char character = findCharacter(number, 3);
			return decodeNumber(character) + "hundred ";

		}
		return "";

	}

	public String decodeNumber(char character)// decodes a number. Used in ones and hundreds place

	{

		String number;
		switch (character) {
		case '0':

			number = "";
			break;
		case '1':

			number = "one ";
			break;
		case '2':

			number = "two ";
			break;
		case '3':

			number = "three ";
			break;
		case '4':

			number = "four ";
			break;
		case '5':

			number = "five ";
			break;
		case '6':

			number = "six ";
			break;
		case '7':

			number = "seven ";
			break;
		case '8':

			number = "eight ";
			break;
		case '9':

			number = "nine ";
			break;

		default:

			number = "not a number";
			break;

		}
		return number;

	}

	public String tensPlace(String theNumber, char character)// decode the tens place
	{

		String number;
		switch (character) {
		case '0':

			number = "";
			break;
		case '1':

			number = teens(theNumber);
			break;
		case '2':

			number = "twenty";
			break;
		case '3':

			number = "thirty";
			break;
		case '4':

			number = "fourty";
			break;
		case '5':

			number = "fifty";
			break;
		case '6':

			number = "sixty";
			break;
		case '7':

			number = "seventy";
			break;

		case '8':

			number = "eighty";
			break;
		case '9':

			number = "ninety";
			break;
		default:

			number = "not a number";
			break;

		}
		return number;

	}

	public String teens(String theNumber)// if number is in the teens go and print out a teen
	{

		String number;
		char character = findCharacter(theNumber, 1);
		switch (character) {
		case '1':

			number = "eleven ";
			break;
		case '2':

			number = "twelve ";
			break;
		case '3':

			number = "thirteen ";
			break;
		case '4':

			number = "fourteen ";
			break;
		case '5':

			number = "fifteen ";
			break;
		case '6':

			number = "sixteen ";
			break;
		case '7':

			number = "seventeen ";
			break;
		case '8':

			number = "eighteen ";
			break;
		case '9':

			number = "nineteen ";
			break;
		default:

			number = "not a number";
			break;

		}
		return number;

	}

	public char findCharacter(String theNumber, int digit) {

		char character;
		int numCharacters = theNumber.length();
		numCharacters -= digit;
		character = theNumber.charAt(numCharacters);
		return character;

	}

}